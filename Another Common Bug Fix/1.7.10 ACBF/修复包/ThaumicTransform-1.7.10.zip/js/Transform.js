var ClassReader = Java.type("org.objectweb.asm.ClassReader");
var ClassNode = Java.type("org.objectweb.asm.tree.ClassNode");
var ClassWriter = Java.type("org.objectweb.asm.ClassWriter");
var Opcodes = Java.type("org.objectweb.asm.Opcodes");
var VarInsnNode = Java.type("org.objectweb.asm.tree.VarInsnNode");
var FieldInsnNode = Java.type("org.objectweb.asm.tree.FieldInsnNode");
var MethodInsnNode = Java.type("org.objectweb.asm.tree.MethodInsnNode");
var LabelNode = Java.type("org.objectweb.asm.tree.LabelNode");
var LineNumberNode = Java.type("org.objectweb.asm.tree.LineNumberNode");
var JumpInsnNode = Java.type("org.objectweb.asm.tree.JumpInsnNode");
var InsnNode = Java.type("org.objectweb.asm.tree.InsnNode");
var LdcInsnNode = Java.type("org.objectweb.asm.tree.LdcInsnNode");
var FrameNode = Java.type("org.objectweb.asm.tree.FrameNode");
var LocalVariableNode = Java.type("org.objectweb.asm.tree.LocalVariableNode");
var Float = Java.type("java.lang.Float");
var ObjectArray = Java.type("java.lang.Object[]");

var disableSwapStuffInPack = ConfigMap.get("disableSwapStuffInPack").equals("true");

var cr = new ClassReader(basicClass);
var cn = new ClassNode(Opcodes.ASM4);
cr.accept(cn, Opcodes.ASM4);
for (var i = 0; i < cn.methods.size(); i++) {
        var mn = cn.methods.get(i);
        if (mn.name.equals("hasStuffInPack") && disableSwapStuffInPack) {
                mn.instructions.clear();
                var l0 = new LabelNode();
                mn.instructions.add(l0);
                mn.instructions.add(new LineNumberNode(17, l0));
                mn.instructions.add(new InsnNode(Opcodes.ICONST_0));
                mn.instructions.add(new InsnNode(Opcodes.IRETURN));
                var l1 = new LabelNode();
                mn.instructions.add(l1);
                mn.localVariables.clear();
                mn.localVariables.add(new LocalVariableNode("this", "Lthaumcraft/common/entities/ContainerPech;", null, l0, l1, 0));
                mn.maxStack = 1;
                mn.maxLocals = 1;
        } else if (mn.name.equals("func_75145_c")) {
                mn.instructions.clear();
                var l0 = new LabelNode();
                mn.instructions.add(l0);
                mn.instructions.add(new LineNumberNode(13, l0));
                mn.instructions.add(new VarInsnNode(Opcodes.ALOAD, 0));
                mn.instructions.add(new FieldInsnNode(Opcodes.GETFIELD, "thaumcraft/common/entities/ContainerPech", "pech", "Lthaumcraft/common/entities/monster/EntityPech;"));
                mn.instructions.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, "thaumcraft/common/entities/monster/EntityPech", "func_70089_S", "()Z", false));
                var l1 = new LabelNode();
                mn.instructions.add(new JumpInsnNode(Opcodes.IFEQ, l1));
                mn.instructions.add(new VarInsnNode(Opcodes.ALOAD, 0));
                mn.instructions.add(new FieldInsnNode(Opcodes.GETFIELD, "thaumcraft/common/entities/ContainerPech", "pech", "Lthaumcraft/common/entities/monster/EntityPech;"));
                mn.instructions.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, "thaumcraft/common/entities/monster/EntityPech", "isTamed", "()Z", false));
                mn.instructions.add(new JumpInsnNode(Opcodes.IFEQ, l1));
                mn.instructions.add(new VarInsnNode(Opcodes.ALOAD, 0));
                mn.instructions.add(new FieldInsnNode(Opcodes.GETFIELD, "thaumcraft/common/entities/ContainerPech", "pech", "Lthaumcraft/common/entities/monster/EntityPech;"));
                mn.instructions.add(new VarInsnNode(Opcodes.ALOAD, 1));
                mn.instructions.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, "thaumcraft/common/entities/monster/EntityPech", "func_70032_d", "(Lnet/minecraft/entity/Entity;)F", false));
                mn.instructions.add(new LdcInsnNode(new Float("8.0")));
                mn.instructions.add(new InsnNode(Opcodes.FCMPG));
                mn.instructions.add(new JumpInsnNode(Opcodes.IFGE, l1));
                mn.instructions.add(new InsnNode(Opcodes.ICONST_1));
                var l2 = new LabelNode();
                mn.instructions.add(new JumpInsnNode(Opcodes.GOTO, l2));
                mn.instructions.add(l1);
                mn.instructions.add(new FrameNode(Opcodes.F_SAME, 0, null, 0, null));
                mn.instructions.add(new InsnNode(Opcodes.ICONST_0));
                mn.instructions.add(l2);
                mn.instructions.add(new FrameNode(Opcodes.F_SAME1, 0, null, 1, Java.to([Opcodes.INTEGER], ObjectArray)));
                mn.instructions.add(new InsnNode(Opcodes.IRETURN));
                var l3 = new LabelNode();
                mn.instructions.add(l3);
                mn.localVariables.clear();
                mn.localVariables.add(new LocalVariableNode("this", "Lthaumcraft/common/entities/ContainerPech;", null, l0, l3, 0));
                mn.localVariables.add(new LocalVariableNode("player", "Lnet/minecraft/entity/player/EntityPlayer;", null, l0, l3, 1));
                mn.maxStack = 2;
                mn.maxLocals = 2;
        }
}
var cw = new ClassWriter(0);
cn.accept(cw);
basicClass = cw.toByteArray();