var ClassReader = Java.type("org.objectweb.asm.ClassReader");
var ClassNode = Java.type("org.objectweb.asm.tree.ClassNode");
var ClassWriter = Java.type("org.objectweb.asm.ClassWriter");
var Opcodes = Java.type("org.objectweb.asm.Opcodes");
var InsnNode = Java.type("org.objectweb.asm.tree.InsnNode");
var IntInsnNode = Java.type("org.objectweb.asm.tree.IntInsnNode");
var LdcInsnNode = Java.type("org.objectweb.asm.tree.LdcInsnNode");
var MethodInsnNode = Java.type("org.objectweb.asm.tree.MethodInsnNode");
var JavaNumber = Java.type("java.lang.Number");
var Integer = Java.type("java.lang.Integer");

function getAbstractInsnNode(i) {
        if (i >= -128 && i <= 127) {
                return new IntInsnNode(Opcodes.BIPUSH, i);
        } else if (i >= -32768 && i <= 32767) {
                return new IntInsnNode(Opcodes.SIPUSH, i);
        } else {
                return new LdcInsnNode(new Integer(i));
        }
}

var cr = new ClassReader(basicClass);
var cn = new ClassNode(Opcodes.ASM4);
cr.accept(cn, Opcodes.ASM4);
for (var i = 0; i < cn.methods.size(); i++) {
        var mn = cn.methods.get(i);
        if (mn.name.equals("<clinit>")) {
                for (var j = 0; j < mn.instructions.size(); j++) {
                        var ain = mn.instructions.get(j);
                        if (ain instanceof IntInsnNode) {
                                switch (ain.operand) {
                                        case 9999:
                                                mn.instructions.set(ain, getAbstractInsnNode(Number(ConfigMap.get("level1")) - 1));
                                                break;
                                        case 10000:
                                                mn.instructions.set(ain, getAbstractInsnNode(Number(ConfigMap.get("level1"))));
                                                break;
                                }
                        } else if (ain instanceof LdcInsnNode && ain.cst instanceof JavaNumber) {
                                switch (ain.cst.intValue()) {
                                        case 999999:
                                                mn.instructions.set(ain, getAbstractInsnNode(Number(ConfigMap.get("level2")) - 1));
                                                break;
                                        case 1000000:
                                                mn.instructions.set(ain, getAbstractInsnNode(Number(ConfigMap.get("level2"))));
                                                break;
                                        case 9999999:
                                                mn.instructions.set(ain, getAbstractInsnNode(Number(ConfigMap.get("level3")) - 1));
                                                break;
                                        case 10000000:
                                                mn.instructions.set(ain, getAbstractInsnNode(Number(ConfigMap.get("level3"))));
                                                break;
                                        case 99999999:
                                                mn.instructions.set(ain, getAbstractInsnNode(Number(ConfigMap.get("level4")) - 1));
                                                break;
                                        case 100000000:
                                                mn.instructions.set(ain, getAbstractInsnNode(Number(ConfigMap.get("level4"))));
                                                break;
                                        case 999999999:
                                                mn.instructions.set(ain, getAbstractInsnNode(Number(ConfigMap.get("level5")) - 1));
                                                break;
                                        case 1000000000:
                                                mn.instructions.set(ain, getAbstractInsnNode(Number(ConfigMap.get("level5"))));
                                                break;
                                }
                        }
                }
        } else if (mn.name.equals("getLevel")) {
                var ain = mn.instructions.getFirst();
                var preIsVarInsn = false;
                while (!preIsVarInsn || ain.getOpcode() != Opcodes.IRETURN) {
                        preIsVarInsn = ain.getOpcode() == Opcodes.ILOAD && ain.var == 2;
                        ain = ain.getNext();
                }
                mn.instructions.insertBefore(ain, new InsnNode(Opcodes.ICONST_0 + Math.min(5, Math.max(0, Number(ConfigMap.get("levelLimit"))))));
                mn.instructions.insertBefore(ain, new MethodInsnNode(Opcodes.INVOKESTATIC, "java/lang/Math", "min", "(II)I", false));
        }
}
var cw = new ClassWriter(0);
cn.accept(cw);
basicClass = cw.toByteArray();